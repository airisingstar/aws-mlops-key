# AWS MLOps Key — Boss Key Engine 🚀

**What this is:** a fully working, annotated *Golden MLOps* pipeline for AWS.
It provisions a VPC, artifact stores (S3/ECR/Model Registry), a CI/CD pipeline
(CodeCommit → CodeBuild → CodePipeline), and deploys a SageMaker Endpoint via
CloudFormation.

**Who it's for:** non‑infra founders and busy teams. Answer a few prompts (or
set a `.tfvars`) and press launch — Boss Key (future UI) will call this repo
under the hood.

---

## Quick Start

```bash
cp envs/client-template.tfvars envs/client-demo.tfvars
# edit values if you want, then:
terraform init
terraform apply -var-file=envs/client-demo.tfvars
```

After apply, a CodeCommit repo named `<name_prefix>-mlops-repo` is created.
Push the contents of `app_src/` there to trigger the pipeline.

---

## What gets created

- **VPC** with two private subnets
- **S3** bucket for model artifacts
- **ECR** repository for inference images
- **SageMaker Model Registry** (Model Package Group)
- **CodeCommit** repository
- **CodeBuild** projects (build image & register model)
- **CodePipeline** (Source → Build → Register → Approval → Deploy)
- **CloudFormation StackSet** that deploys a **SageMaker Endpoint**
- **(Optional) Monitoring** bucket & dashboard (starter)

---

## Repo Map

- `modules/environment` – brains that wires everything together
- `modules/shared_vpc` – minimal VPC + subnets
- `modules/artifact_foundation` – S3/ECR/Model Registry
- `modules/cicd_pipeline` – CodeCommit/Build/Pipeline (+ buildspecs)
- `modules/endpoint_stackset` – StackSet to create SageMaker Endpoint
- `modules/ops_monitoring` – starter monitoring
- `app_src/` – tiny FastAPI app & placeholder model for demos
- `envs/*.tfvars` – per‑client / per‑env presets
- `scripts/*.sh` – one‑liners to onboard clients or deploy/destroy
- `.github/workflows/deploy.yml` – optional GitHub Actions workflow

---

© 2025 MyAiToolset LLC · Boss Key engine
